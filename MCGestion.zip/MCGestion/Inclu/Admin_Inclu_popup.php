<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html" charset="utf-8" />
<meta http-equiv="Content-Language" content="es-es">
<META NAME="Language" CONTENT="Spanish">

<meta name="description" content="Juan Manuel Barros Pazos, Descargas " />

<meta name="keywords" content="Juan Manuel Barros Pazos, Descargas " />
<meta name="robots" content="all, index, follow" />

<meta name="audience" content="All" />

<title>Juan Barros Pazos</title>
<link href="../Css/Descargas.css" rel="stylesheet" type="text/css" />


<script src="../MenuVertical/SpryMenuBar.js" type="text/javascript"></script>
<link href="../MenuVertical/SpryMenuBarVertical.css" rel="stylesheet" type="text/css" />

<link href="../Admin/favicon.ico" type='image/ico' rel='shortcut icon' />

<meta name="google-site-verification" content="eZH2zCJFS0R2mpv-pG5sLmYowSRSmDA48lBLzwfFj1I" />


</head>

<body topmargin="0">
<div>

  <div style="clear:both"></div>
   
   	<div style="margin-top:10px">
	</div>
			  <div style="clear:both"></div>
        

  <div id="Caja2Admin">


