    <div class="limpiar"></div>
  
</div>

        
 
<div style="clear:both"></div>


<div id="footer">&copy; Juan Barr&oacute;s Pazos 2001.</div>

</div>

</body>

</html>