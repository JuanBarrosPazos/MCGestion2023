</div>
  
<div style="clear:both"></div>

</div>

<div id="footer">&copy; Juan Barr&oacute;s Pazos 2001.</div>

</body>

<script type="text/javascript">
swfobject.registerObject("FlashID");
swfobject.registerObject("FlashID2");
</script>

</html>
