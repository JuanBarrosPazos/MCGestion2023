<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html" charset="utf-8" />
<meta http-equiv="Content-Language" content="es-es">
<META NAME="Language" CONTENT="Spanish">

<meta name="description" content="Juan Manuel Barros Pazos, Descargas " />

<meta name="keywords" content="Juan Manuel Barros Pazos, Descargas " />
<meta name="robots" content="all, index, follow" />

<meta name="audience" content="All" />

<title>Juan Barros Pazos</title>
<link href="Css/Descargas.css" rel="stylesheet" type="text/css" />

<link href="Admin/favicon.ico" type='image/ico' rel='shortcut icon' />

<meta name="google-site-verification" content="eZH2zCJFS0R2mpv-pG5sLmYowSRSmDA48lBLzwfFj1I" />

<script src="MenuVertical/SpryMenuBar.js" type="text/javascript"></script>
<link href="MenuVertical/SpryMenuBarVertical.css" rel="stylesheet" type="text/css" />

<script src="Scripts/swfobject_modified.js" type="text/javascript"></script>
<script type="text/JavaScript">

function limitat(elEvento, maximoCaracteres) {
  var elemento = document.getElementById("titulo");
 
  var evento = elEvento || window.event;
  var codigoCaracter = evento.charCode || evento.keyCode;
  if(codigoCaracter == 37 || codigoCaracter == 39) {
    return true;
  }
 
  if(codigoCaracter == 8 || codigoCaracter == 46) {
    return true;
  }
  else if(elemento.value.length >= maximoCaracteres ) {
    return false;
  }
  else {
    return true;
  }
}
 
function actualizaInfot(maximoCaracteres) {
  var elemento = document.getElementById("titulo");
  var info = document.getElementById("infot");
 
  if(elemento.value.length >= maximoCaracteres ) {
    info.innerHTML = "Máximo "+maximoCaracteres+" caracteres";
  }
  else {
    info.innerHTML = "You can write up to "+(maximoCaracteres-elemento.value.length)+" additional characters";
  }
}

</script>


<script type="text/JavaScript">

function limita(elEvento, maximoCaracteres) {
  var elemento = document.getElementById("modulos");
 
  var evento = elEvento || window.event;
  var codigoCaracter = evento.charCode || evento.keyCode;
  if(codigoCaracter == 37 || codigoCaracter == 39) {
    return true;
  }
 
  if(codigoCaracter == 8 || codigoCaracter == 46) {
    return true;
  }
  else if(elemento.value.length >= maximoCaracteres ) {
    return false;
  }
  else {
    return true;
  }
}
 
function actualizaInfo(maximoCaracteres) {
  var elemento = document.getElementById("modulos");
  var info = document.getElementById("infom");
 
  if(elemento.value.length >= maximoCaracteres ) {
    info.innerHTML = "Máximo "+maximoCaracteres+" caracteres";
  }
  else {
    info.innerHTML = "You can write up to "+(maximoCaracteres-elemento.value.length)+" additional characters";
  }
}

</script>


<script type="text/JavaScript">

function limitaa(elEvento, maximoCaracteres) {
  var elemento = document.getElementById("academia");
 
  var evento = elEvento || window.event;
  var codigoCaracter = evento.charCode || evento.keyCode;
  if(codigoCaracter == 37 || codigoCaracter == 39) {
    return true;
  }
 
  if(codigoCaracter == 8 || codigoCaracter == 46) {
    return true;
  }
  else if(elemento.value.length >= maximoCaracteres ) {
    return false;
  }
  else {
    return true;
  }
}
 
function actualizaInfoa(maximoCaracteres) {
  var elemento = document.getElementById("academia");
  var info = document.getElementById("infoa");
 
  if(elemento.value.length >= maximoCaracteres ) {
    info.innerHTML = "Máximo "+maximoCaracteres+" caracteres";
  }
  else {
    info.innerHTML = "You can write up to "+(maximoCaracteres-elemento.value.length)+" additional characters";
  }
}

</script>


<script type="text/JavaScript">

function limitac(elEvento, maximoCaracteres) {
  var elemento = document.getElementById("coment");
 
  var evento = elEvento || window.event;
  var codigoCaracter = evento.charCode || evento.keyCode;
  if(codigoCaracter == 37 || codigoCaracter == 39) {
    return true;
  }
 
  if(codigoCaracter == 8 || codigoCaracter == 46) {
    return true;
  }
  else if(elemento.value.length >= maximoCaracteres ) {
    return false;
  }
  else {
    return true;
  }
}
 
function actualizaInfoc(maximoCaracteres) {
  var elemento = document.getElementById("coment");
  var info = document.getElementById("infoc");
 
  if(elemento.value.length >= maximoCaracteres ) {
    info.innerHTML = "Máximo "+maximoCaracteres+" caracteres";
  }
  else {
    info.innerHTML = "You can write up to "+(maximoCaracteres-elemento.value.length)+" additional characters";
  }
}

</script>


</head>

<body topmargin="0">
<div id="Conte">

  <div id="head"> 
  			<span style="font-size:18px">
  							JUAN MANUEL BARR&Oacute;S PAZOS
            </span>
  	</br>
  			<span style="font-size:12px">
    						PALMA DE MALLORCA ~ PROGRAMACI&Oacute;N & DISE&Ntilde;O.
            </span>
   </div>

  				<div style="clear:both"></div>
   
   <div style="margin-top:10px; text-align:center">
  			<span style="font-size:12px; color:#59746A">
                        	ESTÁ EN LA ZONA DE ADMINISTRACIÓN
            </span>
</div>
			 	<div style="clear:both"></div>
        

  <div id="Caja2Admin">


